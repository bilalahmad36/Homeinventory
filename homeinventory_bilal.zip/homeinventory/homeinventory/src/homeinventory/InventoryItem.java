package homeinventory;

public class InventoryItem {
    public String description;
    public String location;
    public String serialNumber;
    public boolean marked;
    public String purchasePrice;
    public String purchaseDate;
    public String purchaseLocation;
    public String note;
    public String photoFile;
}